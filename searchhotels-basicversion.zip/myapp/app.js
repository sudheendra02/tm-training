import express from 'express'
const app = express()
const port = 3000
import jsonresponse from '/home/sudheendravemula/Documents/Sudheendra/hotels.json'
import {calculateLevenshteinDistance,sortbyname} from "./sort-hotels.js" 
import Hotel from "./Hotel.js"

console.log(Hotel)

function hotelnamematches(searchstring,hotelname)
{	
	
	var indexofchar=0;
	for(var j=0;j<searchstring.length;j++)
	{
		indexofchar =hotelname.indexOf(searchstring[j], indexofchar);
		if(indexofchar==-1)
		{
			return false;
		}
	}
	return true;

}

function controller(req, res) 
{
	var searchstring = req.query.key.toLowerCase()
	var cuisine = req.query.cuisine
	var sortseq = req.query.sortby.split(",")
	var filterby = req.query.filterby.split(",")
	/*gets the json file from the local storage */
	
	var filteredhotels=[];
	for (var i = 0,j=0; i < jsonresponse.length; i++) {
		if (hotelnamematches(searchstring,jsonresponse[i].name.toLowerCase()))
		{
			var lsdistance = calculateLevenshteinDistance(searchstring,jsonresponse[i].name)
			filteredhotels[j] = new Hotel(jsonresponse[i].name.toLowerCase(),jsonresponse[i].cuisine,jsonresponse[i].hotelRating,lsdistance)
			j++;
		}
		
	}
	filteredhotels = sortbyname(filteredhotels,sortseq[0],cuisine);

	res.send(filteredhotels)
	
}

app.get('/', controller)

app.listen(port)