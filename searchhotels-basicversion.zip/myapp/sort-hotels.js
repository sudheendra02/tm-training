export function sortbyname(filteredhotels,sortseq,cuisine) {

	filteredhotels.sort(function compare(obj1,obj2) 
	{
       	if (obj1.getnamedistance()>obj2.getnamedistance()) return 1;
       	if (obj1.getnamedistance()<obj2.getnamedistance()) return -1;
       	else
       	{
       		console.log(sortseq);
       		if (sortseq ===  "rating")
   			{
   				console.log("first in rating");
   				return sortbyrating();
   			}
       		else
       		{
       			console.log("first in cuisine");
       			return sortbycuisine();
       		}
       	}
    

    function sortbycuisine() {
		console.log(cuisine);
		var cuisinedistance1 = calculateLevenshteinDistance(obj1.getcuisine(),cuisine);
		var cuisinedistance2 = calculateLevenshteinDistance(obj2.getcuisine(),cuisine);
		if ((cuisinedistance1)>(cuisinedistance2)) return 1;
		if ((cuisinedistance1)<(cuisinedistance2)) return -1;
		else {
			if (sortseq === "rating")
			{
				console.log("exiting from cuisine");
				return 0;
			}
				else
				{
					console.log("going to rating");
					return sortbyrating();
				}	
		}
	}

	function sortbyrating() {
		if (obj1.getrating()>obj2.getrating()) return -1;
	    if (obj1.getrating()<obj2.getrating()) return 1;
	    else
	    {
	    	if (sortseq === "rating")
			{
				console.log("going to cuisine");
				return sortbycuisine();
			}
	   		else
	   		{
	   			console.log("exiting from rating");
	   			return 0;
	   		}	
	    }
	}

	});
	return filteredhotels;
}




export function calculateLevenshteinDistance (a, b) {
	if(a.length == 0) return b.length;
	if(b.length == 0) return a.length;

	var matrix = [];

	var i;
	for(i = 0; i <= b.length; i++)
	{
		matrix[i] = [i];
	}
	var j;
	for(j = 0; j <= a.length; j++)
	{
		matrix[0][j] = j;
	}

	for(i = 1; i <= b.length; i++)
	{
		for(j = 1; j <= a.length; j++)
		{
			if(b.charAt(i-1) == a.charAt(j-1))
			{
				matrix[i][j] = matrix[i-1][j-1];
			} 
			else 
			{
				matrix[i][j] = Math.min(matrix[i-1][j-1] + 1,Math.min(matrix[i][j-1] + 1,matrix[i-1][j] + 1)); 
			}
		}
	}

	return matrix[b.length][a.length];
}


