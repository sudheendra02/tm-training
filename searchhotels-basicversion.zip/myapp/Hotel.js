export default class Hotel  
{
	constructor(name,cuisine,rating,namedistance) 
	{
		this.name = name;
		this.cuisine = cuisine;
		this.rating = rating;
		this.namedistance = namedistance;
	}

	getname()
	{
		return this.name;
	}

	getcuisine()
	{
		return this.cuisine;
	}

	getrating()
	{
		return this.rating;
	}

	getnamedistance()
	{
		return this.namedistance;
	}
}