import express from 'express'
const app = express()
const port = 3000
import jsonresponse from './hotels.json'
import sortbyname from "./sort-hotels.js" 
import hotel from "./hotel.js"
import filterby from "./filterby.js"

function controller(req, res) 
{
	var searchstring = req.query.key.toLowerCase()
	var cuisine = req.query.cuisine
	var sortseq = req.query.sortby.split(",")
	var filterseq = req.query.filterby.split(",")
	var location = req.query.location

	var allhotels = jsonresponse.map( temphotel => new hotel(temphotel.name,temphotel.cuisine,temphotel.hotelRating,temphotel.city,temphotel.priceperperson));
	
	var filteredhotels=allhotels.map(hotel=>hotel);
	
	filterseq.forEach((filtername) => {
		filteredhotels = filterby(filtername,filteredhotels,searchstring,cuisine,location);
	});
	
	filteredhotels = sortbyname(filteredhotels,sortseq,searchstring,cuisine)

	// console.log(filteredhotels);

	res.send(filteredhotels)
	
}

app.get('/', controller)

app.listen(port)