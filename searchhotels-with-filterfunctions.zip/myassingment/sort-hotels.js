export default function sortbyname(filteredhotels,sortseq,searchstring,cuisine) {
	var index = 0;
	filteredhotels.sort(function compare(obj1,obj2) 
	{
		var dist1 = calculateLevenshteinDistance(obj1.getname(),searchstring);
		var dist2 = calculateLevenshteinDistance(obj2.getname(),searchstring);
		if (dist1>dist2) return 1;
       	else if (dist1<dist2) return -1;
       	else if(dist1 === dist2){
       		console.log("printing",index)
       		if(index < sortseq.length) {console.log("hiii"); return sortbyseq();}
       		else return 0;
       	}
       	
	    function sortbyseq(){
	    	console.log("this is sort seq")
			if (sortseq[index] === "rating") { index++;return sortbyrating();}
			else if (sortseq[index] === "cuisine") { index++;return sortbycuisine();}
			else if (sortseq[index] === "price") { index++;return sortbyprice();}
		}

	    function sortbycuisine() {
	    	console.log("i am in cuisine")
			var cuisinedistance1 = calculateLevenshteinDistance(obj1.getcuisine(),cuisine);
			var cuisinedistance2 = calculateLevenshteinDistance(obj2.getcuisine(),cuisine);
			if ((cuisinedistance1)>(cuisinedistance2)) return 1;
			if ((cuisinedistance1)<(cuisinedistance2)) return -1;
			else {
				console.log("cuisine is same..")
				if(index < sortseq.length) {return sortbyseq();}
				else return 0;	
			}
		}

		function sortbyrating() {
			console.log("i am in rating");
			if (obj1.getrating()>obj2.getrating()) return -1;
		    if (obj1.getrating()<obj2.getrating()) return 1;
		    else
		    {
		    	if(index < sortseq.length) {return sortbyseq();}
				else return 0;	
		    }
		}

		function sortbyprice() {
			console.log("i am in price");
			if (obj1.getprice()>obj2.getprice()) return 1;
		    if (obj1.getprice()<obj2.getprice()) return -1;
		    else
		    {
		    	if(index < sortseq.length) {return sortbyseq();}
				else return 0;	
		    }
		}

	});
	return filteredhotels;
}

function calculateLevenshteinDistance(string1,string2){
	if(string1.length == 0) return string2.length;
	if(string2.length == 0) return string1.length;

	var matrix = [];

	var arrayofstring1 = string1.split("");
	var arrayofstring2 = string2.split("");
	
	// var indexesofstring1 = Array.from(Array(arrayofstring1.length+1).keys())
	var indexesofstring2 = Array.from(Array(arrayofstring2.length+1).keys())


	matrix = indexesofstring2.map(i => matrix[i] = [i]);
	matrix[0] = Array.from(Array(arrayofstring1.length).keys());


	var index1 = 0;

	arrayofstring2.forEach( x => {
			var index2 = 0;
			index1 = arrayofstring2.indexOf(x,index1)+1
				
			arrayofstring1.forEach( y => {
				index2 = arrayofstring1.indexOf(y,index2)+1
				if( x === y){
					matrix[index1][index2] = matrix[index1-1][index2-1]
				}
				else{
					matrix[index1][index2] = Math.min(matrix[index1-1][index2-1]+1,
													Math.min(matrix[index1][index2-1]+1,
																matrix[index1-1][index2]+1))

				}

			})
	})
	return matrix[arrayofstring2.length-1][arrayofstring1.length-1];

}