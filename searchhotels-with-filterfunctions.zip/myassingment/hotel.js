export default class hotel {
	constructor(name,cuisine,rating,city,price) {
		this.name = name;
		this.cuisine = cuisine;
		this.rating = rating;
		this.city = city;
		this.price = price
	}

	getname() {
		return this.name;
	}

	getcuisine() {
		return this.cuisine;
	}

	getrating() {
		return this.rating;
	}

	getcity() {
		return this.city;
	}

	getprice() {
		return this.city;
	}

}