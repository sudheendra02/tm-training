export default function filterby(filtername,allhotels,searchstring,cuisine,location){
	if (filtername === "name"){
		return (function (){
				return allhotels.filter(hotel => 
					{return hotel.getname().toLowerCase().includes(searchstring.toLowerCase())});
			}());
		}
	else if (filtername === "cuisine"){
		return (function (){
				return allhotels.filter(hotel => 
					{return hotel.getcuisine().toLowerCase().includes(cuisine.toLowerCase())});
			}());
	}
	else if (filtername === "location"){
		return (function (){ 
				return allhotels.filter(hotel => 
					{return hotel.getcity().toLowerCase().includes(location.toLowerCase())});
			}());
	}
	else{return allhotels}
}





